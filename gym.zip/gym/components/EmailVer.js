import { Text, View, StyleSheet, TouchableOpacity, SafeAreaView,TouchableHighlight, TextInput} from 'react-native';
import Constants from 'expo-constants';

export default function EmailV() {
  return (
    <SafeAreaView style={styles.container}>
    <View style={styles.box}>{/*will be a box for now*/}
    <View style={styles.circle}/>
    </View>
    <Text style={styles.userText}>Please enter the 4 digit code sent to your email.</Text>
      <TextInput placeholder='---   ---   ---   ---' placeholderTextColor='#FFFFFF' style={styles.inp}/>
      <TouchableOpacity style={styles.button}>
        <Text style={styles.paragraph}>Verify</Text>
      </TouchableOpacity>
      <TouchableOpacity>
        <Text style={styles.forgot}><Text style={{color:'#B8F14A'}}>Resend</Text> Email</Text>
      </TouchableOpacity>
      <TouchableOpacity>
        <Text style={styles.forgot}>Change Email</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: 'center',
    // alignContent:'center',
    backgroundColor: '#2C2C2E',

  },
  inp: {
    marginTop:7,
    backgroundColor: '#2C2C2E',
    borderRadius: 20,
    borderWidth: 3,
    borderColor: '#757575',
    marginLeft:30,
    marginRight:30,
    paddingLeft:20,
    padding:10,
    fontSize: 15,
    textAlign: 'center',
    color: "#FFFFFF",
  },
  userText:{
    margin: 10,
    marginLeft:30,
    marginRight:30,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#FFFFFF',
  }, 
  button: {
    marginTop:40,
    marginBottom: 15,
    backgroundColor: '#B8F14A',
    borderRadius: 10,
    marginLeft:75,
    marginRight:75,

  },
  paragraph: {
    margin: 20,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  forgot: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#FFFFFF',
  },
  box:{
    height:200,
    backgroundColor: '#B8F14A',
  },
  circle: {
    height: 150,
    width:200,
    backgroundColor: '#B8F14A',
    borderWidth: 10,
    borderColor: '#000000',
    margin: 20,
    alignSelf:'center',

  }
});