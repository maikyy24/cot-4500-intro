import StartUp from './components/StartUpPage';
import Login from './components/Login'
import SignUp from './components/SignUp';
import EmailV from './components/EmailVer';
export default function App() {
  return (
    <EmailV/>
    /* to view Start Page change Login to StartUp*/
  );
  //yo
}